//用ES6实现单例模式
//单例模式  $ jQuery  $.get axios
//window  回收站 线程池  数据库 open close


// class Person{
//     constructor(name){
//         this.name=name
//         // if(!Person.demo){
//         //     Person.demo=this
//         // }
//         // return Person.demo
//     }
// }

// let c=new Person('卓卓')
// let d=new Person('卓卓')
// console.log(c===d)


//单例模式
// class Person{
//     constructor(){
//         if(!Person.demo){
//             Person.demo = this;
//         }
//         return Person.demo
//     }
//     get(){
//         return this.name
//     }
//     set(name){
//         this.name=name
//     }
// }
// let c=new Person()
// c.set('卓卓')
// console.log(c.get())
// let d=new Person()
// d.set('卓卓')
// console.log(d.get())
// console.log(c===d)


//前端
//字面量
// let Person1={
//     name:'卓卓'
// }
// let s1=Person1;
// let s2=Person1;
// console.log(s1===s2)



//使用代理模式 实现电话号码的拦截
//使用代理模式 实现图片懒加载

let ListP=['1234556']//电话黑名单
let AIphone=function(phone){
    console.log('接听',phone)
}
let proxyIphone=function(phone){
    console.log('电话....响');
    if(ListP.includes(phone)){
        console.log('屏蔽黑名单')
    }else{
        AIphone.call(this,phone)
    }
}
proxyIphone('1234567')
//使用发布订阅模式读取文件数据

let fs=require('fs');
//ES6
class Events{
    constructor(){
        this.callbacks=[]//存储订阅者
        this.result=[]//存储结果
    }
    on(callback){
        this.callbacks.push(callback)
    }
    emit(data){
        this.result.push(data);
        this.callbacks.forEach(c=>c(this.result))
    }
}

//ES5
// function Events(){
//     this.callback=[]//存储订阅者
//     this.result=[] //存储结果
// }
// Events.prototype.on=function(callback){
//     this.callbacks.push(callback)
// }

// Events.prototype.emit=function(data){
//     this.result.push(data)
//     this.callbacks.forEach(c=>c(this.result))
// }
let e=new Events()//实例化

e.on(arr=>{
    if(arr.length==2){
        console.log(arr)
    }
})

e.on(arr=>{
    if(arr.length==2){
        console.log(arr)
    }
})

fs.readFile('./name.txt','utf8',(err,data)=>{
    e.emit(data)
})

fs.readFile('./age.txt','utf8',(err,data)=>{
    e.emit(data)
})
