const fs=require('fs')
function Events(){//中间商
    this.callbacks = []//存储订阅者
    this.result = []//存储结果
}
Events.prototype.on = function(callback){//订阅者
    this.callbacks.push(callback)
}
Events.prototype.emit = function(data){//发布者
    console.log(data)
    this.result.push(data);
    this.callbacks.forEach(c=>c(this.result))
}
let e = new Events()

e.on((arr)=>{
    if(arr.length==2){
        console.log(arr)
    }
})
e.on((arr)=>{
    if(arr.length==2){
        console.log(arr)
    }
})
e.on((arr)=>{
    if(arr.length==2){
        console.log(arr)
    }
})
fs.readFile('./name.txt','utf8',(err,data)=>{
    e.emit(data)
})
fs.readFile('./age.txt','utf8',(err,data)=>{
    e.emit(data)
})