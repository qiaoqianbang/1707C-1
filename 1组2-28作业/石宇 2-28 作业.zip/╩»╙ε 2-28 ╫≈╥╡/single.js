class Person{
    constructor(){
        this.name;
        if(!Person.demo){
            Person.demo=this;
        }
        return Person.demo
    }
    get(){
        return this.name;
    }
    set(name){
        this.name=name
    }
}
let c=new Person()
c.set('aaaa')
console.log(c.get())
let d=new Person()
d.set('bbbb')
console.log(d.get())
console.log(c===d)