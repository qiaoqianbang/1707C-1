// 代理
let List=['12345678'];
let Aphone=function(phone){
    console.log('接听',phone)
}
let proxyPhone=function(phone){
    console.log('电话，，，响');
    if(List.includes(phone)){
        console.log('屏蔽黑名单');
    }else{
        Aphone.call(this,phone)
    }
}
proxyPhone('12345678')
proxyPhone('1234')