let ListP = ['12345678'] //电话黑名单

let AIphone = function(phone){
    console.log('接听',phone)
}

let proxyIphone = function(phone){
    console.log('电话。。。响')
    if(ListP.includes(phone)){
        console.log('屏蔽黑名单')
    }else{
        // call apply bin 显示传递
        AIphone.call(this.phone)
    }
}
// proxyIphone('12345678')
proxyIphone('123345678888889')
