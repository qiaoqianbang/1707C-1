//单例模式
class Person{
    constructor(){
        this.name;
        if(!Person.demo){
            Person.demo = this;
        }
        return Person.demo
    }
    get(){
        return this.name
    }
    set(name){
        this.name = name
    }
}
let c = new Person()
c.set("yilei")
console.log(c.get())
let d = new Person()
d.set("Yilei")
console.log(d.get())
console.log(c === d)