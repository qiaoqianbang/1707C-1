// 发布订阅模式
let fs = require('fs');
function Events(){
    this.callbacks = []
    this.result = []
}

Events.prototype.on = function(callback){
    this.callbacks.push(callback)
}

Events.prototype.emit = function(data){
    this.result.push(data);
    this.callbacks.forEach(c=>c(this.result))
}

let e = new Events()
e.on((arr)=>{
    if(arr.length==2){
        console.log(arr)
    }
})
e.on((arr)=>{
    if(arr.length==2){
        console.log(arr)
    }
})
fs.readFile('./name.txt','utf8',(err,data)=>{
    e.emit(data)
})
fs.readFile('./age.txt','utf8',(err,data)=>{
    e.emit(data)
})