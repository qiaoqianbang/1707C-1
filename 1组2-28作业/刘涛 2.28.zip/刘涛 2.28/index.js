// 单列模式 :
// 单列模式的应用场景 :
// 为什么要使用单列: 解决内存问题 同样的工作没必要创建n个实列 单列相当于人都要吃饭，饭店可以容纳，为什么要一个人去一个饭店呢
// class DL {
//   constructor(className, phone) {
//     this.className = className
//     this.phone = phone
//     if (!DL.g) {
//       DL.g = this
//     }
//     return DL.g
//   }
//   get(value) {
//     if ("人".includes(value)) {
//       return this.phone
//     }
//     return this.className
//   }
//   set(name) {
//     if (Number(name)) {
//       this.phone = name
//     }
//     this.className = name
//   }
// }

// let classBox = new DL("1707C", 90)
// // b.set("1707C")
// console.log(classBox.set(91))
// console.log(classBox.get("人"))


// 代理模式:
// 代理模式的作用:1. 拦截监视外部变化2.降低函数的复杂度 3.合理化分配
// 实现电话号码的拦截

// let str = ["15735578964"]

// function proxy(phone) {
//   console.log("接听" + phone)
// }


// function util(phone) {
//   if (str.includes(phone)) {
//     console.log("拦截 黑名单")
//   } else {
//     proxy.apply(this, [phone])
//   }
// }
// util("157355789d64")

// let p = {
//   phone: "您已被拦截"
// }

// 发布订阅者模式
// 发布 => 中间商 => 订阅者
// let fs = require("fs")
// class a {
//   constructor() {
//     this.call = []//订阅者
//     this.res = []//发布者
//   }
//   on(calls) {
//     this.call.push(calls)
//   }
//   emit(data) {
//     this.res.push(data)
//     this.call.forEach(item => {
//       item(this.res)
//     })
//   }
// }

// let e = new a()

// e.on((arr) => {
//   if (arr.length >= 2) {
//     console.log(arr, "??")
//   }

// })
// e.on((arr) => {
//   if (arr.length >= 2) {
//     console.log(arr, "??")
//   }
// })

// fs.readFile("./fb.txt", "utf-8", (error, data) => {
//   e.emit(data)
// })

// fs.readFile("./dy.txt", "utf-8", (error, data) => {
//   e.emit(data)
// })




































// let p = {
//   name: "lt",
//   age: 21
// }

// let a = new Proxy(p, {
//   get(tag, key) {
//     if (key != "age") {
//       return tag[key]
//     }
//     return "总是18岁"
//   },
//   set(tag, key, val) {
//     if (key === "role") {
//       tag[key] = val === "S" ? "老师" : "学生"
//     }
//     return key
//   }
// })
// a.role = "S"
// console.log(a.role)



