// ⽤ES6实现单例模式
// //可以修改和读取班级名字，班级⼈数
class ClassName{
 constructor(){
    this.name;
    this.classNum;
    if(!ClassName.demo){
        ClassName.demo=this;
    }
    return ClassName.demo
 }
 get(){
     return {name:this.name,class:this.classNum}
 }
 set(name,classNum){
     this.name=name;
     this.classNum=classNum;
 }
}
// let changeClass=new ClassName();
// changeClass.set('loudina',"1707C")
// console.log(changeClass.get());

// 使⽤代理模式 实现电话号码的拦截

let ListPhone=['123456789'];
let AIphone=function(phone){
    console.log('接听',phone)
}
let proxyIphone=function(phone){
    if(ListPhone.includes(phone)){
        console.log('此电话加入黑名单')
    }else{
        AIphone.call(this,phone)
    }
}

proxyIphone('12345679')

// let AIphone={
//     phone:["123456789"],
//     title:''
// }//电话黑名单
// const ProxyPhone=new Proxy(AIphone,{
//     get(target,key){
//        return target[key]
//     },
//     set(target,key,value){
//         console.log(target,key,value)
//         if(target[key].includes(value)){
//             console.log(target['title'])
//             target['title']='此电话被拦截'
//         }else{
//             return target['title']=value
//         }
//     }
// })
// ProxyPhone.phone="12345679"
// console.log(ProxyPhone.title)

// 使⽤代理模式 实现图⽚懒加载

// let myImg=(function(){
//     let imgNode=document.createElement('img')
//     document.body.appendChild(imgNode)
//     return {
//         setSrc:(src)=>{
//             imgNode.src=src;
//         }
//     }
// })();
// let proxyImg=(function(){
//     let img=new Image() //创建灯塔
//     console.log(img,"111")
//     img.onload=()=>{
//         myImg.setSrc(img.src)
//     }
//     return {
//         setSrc:(src)=>{
//             myImg.setSrc('./img1.jpg')//先加载本地
//             setTimeout(()=>{ img.src=src},2000)//延迟两秒在加载要加载的图片
//         }
//     }
// })()
// proxyImg.setSrc('https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1582908258973&di=e782d51134cbbefaf269f322836ad426&imgtype=0&src=http%3A%2F%2Fwww.17qq.com%2Fimg_qqtouxiang%2F84138559.jpeg')

// 使⽤发布订阅模式读取⽂件数据
let fs = require('fs')
// function Events(){//中间商
//     this.callBacks=[];//存储订阅者
//     this.result=[];//存储结果
// }
// Events.prototype.on=function(callBack){
//     this.callBacks.push(callBack)
// }
// Events.prototype.emit=function(data){
//     this.result.push(data);
//     this.callBacks.forEach(item=>item(this.result))
// }
// let e=new Events()

// e.on((arr)=>{//订阅者
//     if(arr.length===2){
//         console.log(arr)
//     }
// })
// e.on((arr)=>{//订阅者
//     if(arr.length===2){
//         console.log(arr)
//     }
// })

// fs.readFile('./name.txt','utf8',(err,data)=>{
//     e.emit(data)
// })
// fs.readFile('./age.txt','utf8',(err,data)=>{
//     e.emit(data)
// })

class Events{
    constructor(){
        this.callBacks=[];//存储订阅者
        this.result=[];//存储结果
        if(!ClassName.demo){
            ClassName.demo=this;
        }
        return ClassName.demo
    }
    on(callBack){
        this.callBacks.push(callBack)
    }
    emit(data){
        this.result.push(data);
        this.callBacks.forEach(item=>item(this.result))
    }
}
let e=new Events()
e.on((arr)=>{//订阅者
    if(arr.length===2){
        console.log(arr)
    }
})
e.on((arr)=>{//订阅者
    if(arr.length===2){
        console.log(arr)
    }
})

fs.readFile('./name.txt','utf8',(err,data)=>{
    e.emit(data)
})
fs.readFile('./age.txt','utf8',(err,data)=>{
    e.emit(data)
})

