// 冒泡排序
// function sort(arr) {
//   let count = 0;
//   let sum = 0;
//   for (let i = 0; i < arr.length; i++) {
//     ++count
//     for (let j = 0; j < arr.length - 1 - i; j++) {
//       ++sum
//       // [ 5,4, 3, 2, 1]
//       if (arr[j] > arr[j + 1]) {
//         [arr[j + 1], arr[j]] = [arr[j], arr[j + 1]]
//       }
//     }
//   }
//   return count + sum
// }

// console.log(sort([5, 4, 3, 2, 1]))
// 冒泡排序 步骤
//第一次循环 54321 45321 43521 43251 43215  外5次循环  4
//第二次循环 4321  34215 32415  32145        外4次 内3 3
//第三次循环 321  23145 21345          外3 内3 2
//第四次循环 21  12345         外4 内4 1
//第五次循环 1  外5 内0 0


// 选择排序 :找最小值
// let sum = 0;
// let count = 0;
// function xz(arr) {
//   for (let i = 0; i < arr.length - 1; i++) {
//     let index = i
//     sum++
//     for (let j = i + 1; j < arr.length; j++) {
//       count++
//       // [5, 4, 3, 2, 1]
//       if (arr[index] > arr[j]) {
//         // 找到了最小值把它的下标留住
//         index = j
//         console.log(j)
//       }
//     }
//     [arr[i], arr[index]] = [arr[index], arr[i]]
//   }
//   return arr
// }

// console.log(xz([5, 4, 3, 2, 1]))
// 解题步骤
//第一次循环
// 54321 =>(5 > 4 取小4) => (5 > 3 取小3) => (5 > 2 取小2) => (5 > 1 取小1) => 最小值和index值调换 14325 外5内5
//第二次循环 
// 4321  => (4 > 3 取小3) =>(4 > 2 取小2) =>判断不成立(4 > 5取小2) =>  最小值和index值调换 => 12345  外4内4
// 排序完成



// 插入排序

// function sort(arr) {
//   let temp;
//   for (let i = 1; i < arr.length; i++) {
//     let j = i;//3
//     temp = arr[i]//2
//     // [5, 4, 3, 2, 1]
//     // arr[j - 1] 3
//     while (j > 0 && arr[j - 1] > temp) {
//       arr[j] = arr[j - 1]
//       j--
//     }
//     arr[j] = temp;
//     console.log(arr)
//   }
//   return
// }
// console.log(sort([5, 4, 3, 2, 1]))

// 插入排序 步骤
// 第一遍 4321=> 数组第一项留住 下标留住 => 循环条件成立 55321=>45321
// 第二遍 321=> 数组第一项留住 下标留住 => 循环条件成立  45421=>44521=>34521
// 第三遍 32=> 数组第一项留住 下标留住 => 循环条件成立  34531=>23451
// 第三遍 21=> 数组第一项留住 下标留住 => 循环条件成立 12345


// 快速排序
// function sort(arr) {
//   if (arr.length <= 1) {
//     return arr
//   }
//   let pro = arr[0]
//   let left = []
//   let right = []
//   for (let i = 1; i < arr.length; i++) {

//     if (arr[i] >= pro) {
//       right.push(arr[i])
//     } else {
//       left.push(arr[i])
//       console.log(arr[i])

//     }

//   }
//   let l = sort(left)
//   let r = sort(right)
//   return l.concat(pro).concat(r)
// }

// console.log(sort([5, 4, 3, 2, 1]))


// 快速排序
// 第一轮:
// 4321=> 4 < 5  left[4] left[4, 3] left[4, 3, 2] left[4, 3, 2, 1] => 进入递归 arr = [4, 3, 2, 1] pro = [4] left[3] left[3, 2] left[3, 2, 1] => 
// 进入递归 arr = [3, 2, 1] pro = [2] left[2] left[2, 1] =>// 进入递归 arr = [ 2, 1] pro = [2] left[1]
// 第二轮:
// 4321=>arr[4,3,2,1]=>right[4]=>right[]






