//冒泡排序
//代码实现 以及 排序过程图
function swap(array,a,b){
    [array[a],array[b]]=[array[b],array[a]]
}
let n=0;
let sum=0;
function bubbleSort(array){
    const {length}=array
    for(let i=0;i<length;i++){//外层循环决定趟数
        for(let j=0;j<length-1;j++){//内层循环决定次数
            if(array[j]>array[j+1]){
                swap(array,j,j+1)
            }
        }
    }
    return array
}
let arr=[5,4,3,2,1]
console.log(bubbleSort(arr))

// 54321 //原数据
// 45321
// 43521
// 43251
// 43215
// 34215
// 32415
// 32145
// 32145
// 23145
// 21345
// 21345
// 21345
// 12345
// 12345
// 12345
// 12345
// 12345
// 12345
// 12345
// 12345


//选择排序
//代码实现 以及 排序过程图
function selectSort(array=[]){
    let {length}=array
    for(let i=0;i<length-1;i++){//比较的趟数
        let indexMin =i;
        for(let j=i+1;j<length;j++){//通过后面的数进行比较
            if(array[indexMin]>array[j]){
                indexMin = j
            }
        }
        if(i!=indexMin){
            [array[i],array[indexMin]]=[array[indexMin],array[i]]
        }
    }
    return array
}
selectSort(arr)
// 54321
// 14325
// 12345

//插入排序
//代码实现 以及 排序过程图

function insertSort(array){
    const {length} =array;
    for(let i=1;i<length;i++){
        let j=i;
        temp=array[i];
        while(j>0&&array[j-1]>temp){
            array[j]=array[j-1];
            j--
        }
        array[j]=temp
    }
    return array
}
let insertArr=[3,5,1,4,2]
// 3 5142 待插入5
// 35 142 3<5,插入5
// 35 142 待插入1
// 35 142 5>1,换位
// 35 142 3>1,换位
// 135 42 到达索引0，插入1
insertSort(insertArr)

//快速排序
//代码实现 以及 排序过程图

function quickSort(arr=[]){
    if(arr.length<=1){
        return arr
    }
    let provit=arr[0]
    let left=[];
    let right=[];
    for(let i=1;i<arr.length;i++){
        if(arr[i]<=provit){
            left.push(arr[i])
        }else{
            right.push(arr[i])
        }
    }
    let l=quickSort(left);
    let r=quickSort(right);
    return l.concat(provit).concat(r)
}