//插入排序  3 5  1 4 2
function insertSort(array){
    const {length}=array
    for(let i=1;i<length;i++){
        let j=i; //2
        temp=array[i] //1 
        while(j>0&&array[j-1]>temp){
            array[j]=array[j-1];
            j--
        }
        array[j]=temp;
    }
    return array
}
let arr=insertSort([3,5,1,4,2])

// 3 5 1 4 2
// 1 3 5 4 2
// 1 3 4 5 2
// 1 2 3 4 5