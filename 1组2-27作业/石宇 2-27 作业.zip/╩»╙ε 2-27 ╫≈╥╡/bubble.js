//冒泡排序
function BubbleSort(array){
    const {length}=array
    for(let i=0;i<length;i++){
        for(let j=0;j<length-1-i;j++){
            if(array[j]>a[j+1]){
                [array[j],array[j+1]]=[array[j+1],array[j]]
            }
        }
    }
}
let arr=BubbleSort([5,4,3,2,1])
console.log(arr)

// 5 4 3 2 1

// 4 5 3 2 1
// 4 3 5 2 1
// 4 3 2 5 1
// 4 3 2 1 5
// 3 4 2 1 5
// 3 2 4 1 5
// 3 2 1 4 5
// 2 3 1 4 5
// 2 1 3 4 5
// 1 2 3 4 5