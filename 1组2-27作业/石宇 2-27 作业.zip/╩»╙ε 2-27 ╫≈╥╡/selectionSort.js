//选择排序
function selectSort(array=[]){
    let {length}=array
    for(let i=0;i<length-1;i++){
        let min=i;
        for(let j=i+1;j<length;j++){
            if(array[min]>array[j]){
                min=j
            }
        }
        if(i!=min){
            [array[i],array[min]]=[array[min],array[i]]
        }
    }
    return array
}
let arr=selectSort([5,4,3,2,1])
console.log(arr)

// 5 4 3 2 1
// 1 4 3 2 5
// 1 2 3 4 5


