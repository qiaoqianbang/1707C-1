//快速排序
function quickSort(arr){
    if(arr.length<=1){
        return arr;
    }
    var pivot=arr[0];
    var left=[];
    var right=[];
    for(var i=1;i<arr.length;i++){
        if(arr[i]<=pivot){
            left.push(arr[i]);
        }else{
            right.push(arr[i])
        }
    }
    let l=quickSort(left);
    let r=quickSort(right);
    return l.concat(pivot).concat(r)
}
let arr=quickSort([4,3,5,2,1])
console.log(arr)

// 4 3 5 2 1
// 4
// left 3 2 1 
// right 5  

// 3 2 1 
// 3
// left 2 1
// right []

// 2 1
// 2
// left 1
// right []
// [1] return [1]
// l=[1]
// r=[]
// return [1,2]

// return [1,2,3]
// return [1,2,3,4,5]