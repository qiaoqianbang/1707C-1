function swap(arr,a,b){
    [arr[a],arr[b]]=[arr[b],arr[a]]
}
// 冒泡排序// //代码实现 以及 排序过程图

    function BubbleSort(arr){
        const {length}=arr;
        for(let i=0;i<length;i++){
            for(let j=0;j<length-1-i;j++){
                if(arr[j]>arr[j+1]){
                    swap(arr,j,j+1)
                }
            }
        }
        return arr
    }
    // console.log(BubbleSort([2,4,3,5,1]))
    // 2,4,3,5,1 i=0;i<5;i++;
    // i=0  j=0; j<4; j++;  i=1  j=0; j<3; j++;  i=2  j=0; j<2; j++;  i=3 j=0; j<1; j++;  i=4 j=0; j<0; j++;
    // i=0,j=0  2 4 3 5 1   i=1,j=0  2 4 3 1 5   i=2,j=0  2 3 1 4 5   i=3,j=0  1 2 3 4 5  终止循环
    // i=0,j=1  2 3 4 5 1   i=1,j=1  2 3 4 1 5   i=2,j=1  2 1 3 4 5
    // i=0,j=2  2 3 4 5 1   i=1,j=2  2 3 1 4 5
    // i=0,j=3  2 3 4 1 5

// 选择排序// //代码实现 以及 排序过程图
    function selectSort(arr){
        let {length}=arr;
        for(let i=0;i<length-1;i++){
            let indexMin=i;//定义一个最小值下标
            for(let j=i+1;j<length;j++){
                if(arr[indexMin]>arr[j]){ //如果小于
                    indexMin=j  //最小值下标改变
                }
            }
            if(i!=indexMin){ //判断初始最小值下标和循环后下标是否一样
                swap(arr,i,indexMin) //交换值
            }
        }
        return arr
    }
    // console.log(selectSort([2,4,3,5,1]))

    // 2,4,3,5,1 length=5 i=0;i<4;i++
    // i=0; j=1;j<5;j++  indexMin=0   i=1; j=2;j<5;j++  indexMin=1  i=2; j=3;j<5;j++  indexMin=2   i=3; j=4;j<5;j++  indexMin=3
    // i=0,j=1 2,4,3,5,1 indexMin=0   i=1,j=2 1,4,3,5,2 indexMin=2  i=2  j=3 1,2,3,5,4 indexMin=2  i=3  j=4 1,3,2,4,5 indexMin=4
    // i=0,j=2 2,4,3,5,1 indexMin=0   i=1,j=3 1,4,3,5,2 indexMin=2  i=2  j=4 1,2,3,5,4 indexMin=2   1,3,2,4,5
    // i=0,j=3 2,4,3,5,1 indexMin=0   i=1,j=4 1,4,3,5,2 indexMin=4   1,2,3,5,4
    // i=0,j=4 1,4,3,5,2 indexMin=4   1,2,3,5,4
     // 1,4,3,5,2

// 插⼊排序// //代码实现 以及 排序过程图
 
    function insertStort(arr){
        const {length}=arr;
        for(let i=1;i<length;i++){
            let j=i;
            temp=arr[i];
            while(j>0&&arr[j-1]>temp){
                arr[j]=arr[j-1];
                j--
            }
            arr[j]=temp;
        }
        return arr
    }    
    // console.log(insertStort([2,4,3,5,1]))
    // 2,4,3,5,1 i=1;i<5;i++ j=1 temp=4   i=2;i<5;i++ j=2 temp=3      i=3;j=3 temp=5  i=4;j=4 temp=1
    // 1>0&&2>4 false                      3>0&&4>3 true              3>0&&4>5 false   4>0&&5>1
    // 4=4 2,4,3,5,1                       3=4 j-- j=1  2,4,4,5,1     5=5  2,3,4,5,1   1=5 j-- j=3 2,3,4,5,5
                                        // 2,3,4,5,1                                   3>0&&4>1 true 5=4  2,3,4,4,5 j-- j=2
                                                                                    // 2>0&&3>1 true 4=3  2,3,3,4,5 j-- j=1
                                                                                    // 1>0&&2>1 true 3=2  2,2,3,4,5 j-- j=0
                                                                                    // j=0  2=1  1,2,3,4,5


// 快速排序// //代码实现 以及 排序过程图

function quickSort(arr){
    if(arr.length<=1){
        return arr
    }
    let provit=arr[0];
    let left=[];
    let right=[];
    for(let i=1;i<arr.length;i++){
        if(arr[i]<=provit){
            left.push(arr[i])
        }else{
            right.push(arr[i])
        }
    }
    console.log(left,right)
    let l=quickSort(left);
    let r=quickSort(right);
    return l.concat(provit).concat(r)
}
console.log(quickSort([2,4,3,5,1]))

// provit=2;left=[];right=[] i=1;i<5;i++
// i=1 if(4<=2)false right=[4]
// i=2 if(3<=2)false right=[4,3]
// i=3 if(5<=2)false right=[4,3,5]
// i=4 if(1<=2) true left=[1]
// 递归
// right=[4,3,5]
// provit=4;left=[];right=[] i=1;i<3;i++
// i=1 if(3<=4)true left=[3]
// i=2 if(5<=4)false right=[5]

// return 1,2,3,4,5





