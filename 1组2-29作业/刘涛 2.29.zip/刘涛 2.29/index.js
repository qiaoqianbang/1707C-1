// this
// 1.默认指向
// 2.隐士指向
// 3.硬指向
// 4.new 指向

// 第一题
// 默认指向
// function say() {
//   console.log("hello", this.name)
// }
// let per = {
//   name: "per姓名",
//   say: say
// }
// let name = "全局变量"
// let h = per.say
// // 方法通过间接执行没有改变this指向,而是最后调用的所以this是window
// h()
// 打印结果 "hello", undefined

//  第二题
// function say() {
//   console.log("hello", this.name)
// }
// let per1 = {
//   name: "per1姓名",
//   say: function () {
//     setTimeout(function () {
//       console.log("hello", this.name)
//     })
//   }
// }
// let per2 = {
//   name: "per2姓名",
//   say: say
// }
// let name = "全局变量"
// per1.say()
// // setTimeout 里面的函数指向全局 所以是undefined 如果是箭头函数改变了this就是per1姓名
// setTimeout(per2.say, 100)
// // 函数say this指向window 所以undefined
// setTimeout(function () {
//   per2.say()
// }, 100)
// // 隐士转换 将per2的this指向了函数say 打印 hello per2姓名


// // 第三题
// // 默认指向
// function say() {
//   console.log("hello", this.name)
// }
// let per = {
//   name: "per姓名",
//   say: say
// }
// let name = "全局变量"
// let h = per.say

// h.call(per)
// // 硬指向call改变this指向将per 的this覆给 函数say 打印 hello per姓名


// // 第四题
// // 默认指向
// function say() {
//   console.log("hello", this.name)
// }
// let per = {
//   name: "per姓名",
//   say: say
// }
// let name = "全局变量"
// let h = function (fn) {
//   fn()
// }
// h.call(per, per.say)
//call改变this指向将per的this指向window变量h这个函数 函数体内执行回调this指向widow所以undeined
// 打印结果 "hello", undefined


// 第五题
// 默认指向
// function say() {
//   // console.log(this, "this")
//   console.log("hello", this.name)
// }
// let per = {
//   name: "per姓名",
//   say: say
// }
// let name = "全局变量"
// let h = function (fn) {
//   // console.log(this, "this")
//   fn.call(this)
// }
// h.call(per, per.say)
//先将window的this赋给函数h指向window 函数体内回调隐士赋值 this指向per
// 打印结果 "hello",per姓名


// 第六题
// 默认指向
// let a = 0
// let obj = {
//   h: function () {
//     console.log(this)
//     return () => {
//       console.log(this)
//     }
//   },
//   sayH: function () {
//     return function () {
//       console.log(this, "1")
//       return () => {
//         console.log(this, "2")
//       }
//     }
//   },
//   say: () => {
//     console.log(this, "this")
//   }

// }
// let h = obj.h()
// h()
// 对象里的函数this指向对象本身 this指向未改变 打印obj对象
// 打印结果执行俩次 obj对象
// let sayH = obj.sayH()
// let fun1 = sayH()
// fun1()
// 打印结果 全局对象
// obj.say()
// 打印{} 不明白

// 第七题
// 默认指向
let obj = {
  h: function () {
    console.log(this)
    return () => {
      console.log(this)
    }
  },
  sayH: function () {
    return function () {
      console.log(this)
      return () => {
        console.log(this)
      }
    }
  },
  say: () => {
    console.log(this, "this")
  }

}
let sayhi = obj.sayH()
let fun1 = sayhi()
fun1()
// //  sayH第一次调用的时候this真相obj对象 再次调用this指向全局对象
// 打印结果 全局对象 2次



