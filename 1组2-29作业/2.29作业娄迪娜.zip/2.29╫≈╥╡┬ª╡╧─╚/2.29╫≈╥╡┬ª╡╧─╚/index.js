//第⼀题
// function sayHi(){
//     console.log('Hello,', this.name);
//    }
//    var person = {
//     name: 'Person姓名',
//     sayHi: sayHi
//    }
//    var name = '全局变量';
//    var Hi = person.sayHi;//Hello, undefined 不是隐式调用
//    Hi();
   //第⼆题
//    function sayHi(){
//     console.log('Hello,', this.name);
//    }
//    var person1 = {
//     name: 'Person1的值',
//     sayHi: function(){
//     setTimeout(function(){ //setTimeout 改变this指向 为window 所以this.name为undefined
//     console.log('Hello,',this.name);
//     })
//     }
//    }
//    var person2 = {
//     name: 'Person2的值',
//     sayHi: sayHi
//    }
//    var name='全局变量name';
//    person1.sayHi();//Hello, undefined
//    setTimeout(person2.sayHi,100);//Hello, undefined 为默认调用 不是隐式调用
//    setTimeout(function(){
//     person2.sayHi(); //Hello, Person2的值 隐式调用
//    },200);
//    //第三题
//    function sayHi(){
//     console.log('Hello,', this.name);
//    }
//    var person = {
//     name: 'Person名字',
//     sayHi: sayHi
//    }
//    var name = '全局名字';
//    var Hi = person.sayHi;
//    Hi.call(person);//call改变this指向为person  Hello, Person名字
//    //第四题
//    function sayHi(){
//        console.log(this,"1")//this指向全局
//     console.log('Hello,', this.name,"2");
//    }
//    var person = {
//     name: 'Person的值',
//     sayHi: sayHi
//    }
//    var name = '全局的名字';
//    var Hi = function(fn) {
     
//     fn(); //this指向为全局
//     console.log(this)
//    }
//    Hi.call(person, person.sayHi);//Hello, undefined // person.sayHi是默认调用
//    //第五题
//    function sayHi(){
//     console.log(this,"2")//this指向person
//     console.log('Hello,', this.name);
//    }
//    var person = {
//     name: 'Person的题',
//     sayHi: sayHi
//    }
//    var name = '全局变量的值';
//    var Hi = function(fn) {
//     fn.call(this);//改变this指向为person Hello, Person的题
//     // console.log(this)
//    }
//    Hi.call(person, person.sayHi);//Hello, Person的题
//    //第六题
//    var obj = {
//     hi: function(){
//     console.log(this,"1");//hi函数
//     return ()=>{
//     console.log(this,"21");//hi函数
//     }
//     },
//     sayHi: function(){
//         return function() {
//         console.log(this,"3");//全局
//             return ()=>{
//             console.log(this,"4");//全局
//             }
//         }
//     },
//     say: ()=>{
//     console.log(this,"5");//{} 空 箭头函数
//     }
//    }
//    let hi = obj.hi();//this指向hi函数
//    hi();//this指向hi函数
//    let sayHi = obj.sayHi();
//    let fun1 = sayHi();
//    fun1();//this指向全局 默认调用
//    obj.say();
//    //第七题
   var obj = {
    hi: function(){
    console.log(this);
    return ()=>{
    console.log(this);
    }
    },
    sayHi: function(){
    return function() {
    console.log(this,"1");//全局
    return ()=>{
    console.log(this,"2");//全局
    }
    }
    },
    say: ()=>{
    console.log(this,"3");
    }
   }
   let sayHi = obj.sayHi();
   let fun1 = sayHi();//this指向全局
   fun1();//this指向全局
// bin返回的是一个修改函数this指向的函数引用 不二次调用不会显示任何东西
   let fun2 = sayHi.bind(obj)();// 此时的this指向为obj内函数的调用{ hi: [Function: hi], sayHi: [Function: sayHi], say: [Function: say] }
   fun2();//{ hi: [Function: hi], sayHi: [Function: sayHi], say: [Function: say] }