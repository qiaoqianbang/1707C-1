//第一题
// function sayHi(){
//     console.log('Hello',this.name);
//     }
// var person = {
//     name: 'Person姓名',
//     sayHi: sayHi
//     }
// var name ='全局变量';
// //person.sayHi后面加上括号
// // 结果为Hello Person姓名
// //person.sayHi后面不加括号
// // node 结果为Hello undefined  浏览器 结果为Hello Person姓名
// var Hi = person.sayHi;
// Hi();




// //第二题
// function sayHi(){
//     console.log('He11o,', this.name);
//    }
// var person1 = {
//     name: 'Person1的值',
//     sayHi: function(){
//         console.log(1111)
//     setTimeout(function(){
//         console.log(this)
//         console.log("Hello" ,this.name,9999)
//     })
//     }
// }
// var person2 = {
//     name: " Person2的值" ,
//     sayHi: sayHi
// }
// var name='全局变量name'
// person1.sayHi();
//结果为 Hello undefined setTimeout的this指向为Timeout
// setTimeout(person2.sayHi,100);
//结果为 Hello undefined 的this指向为Timeout
// setTimeout(function(){
//     person2.sayHi();
// },200)
// He11o,  Person2的值


// //第三题
// function sayHi(){
//     console.log('Hello',this.name);
// }
// var person={
//     name:'person名字',
//     sayHi:sayHi
// }
// var name='全局名字';
// var Hi=person.sayHi;
// Hi.call(person);
// 结果为 Hello person名字call的this指向为person

// //第四题
// function sayHi(){
//     console.log('Hello',this.name);
// }
// var person={
//     name:'Person的值',
//     sayHi:sayHi
// }
// var name='全局的名字'
// var Hi=function(fn){
//     fn();
// }
// Hi.call(person,person.sayHi)
//结果为Hello undefined  call指向为person person.sayHi为隐式指向

// //第五题
// function sayHi(){
//     console.log('Hello',this.name)
// }
// var person={
//     name:'person的题',
//     sayHi:sayHi
// }
// var name='全局变量的值'
// var Hi=function(fn){
//     // console.log(fn,999)sayHi
//     fn.call(this)
// }
// Hi.call(person,person.sayHi);
// 结果 Hello person的题

// //第六题
// var obj={
//     hi:function(){
//         console.log(this);
//         //this指向{ hi: [Function: hi], sayHi: [Function: sayHi], say: [Function: say] }
//         return ()=>{
//             console.log(this)
//         //this指向 { hi: [Function: hi], sayHi: [Function: sayHi], say: [Function: say] }
//         }
//     },
//     sayHi:function(){
//         return function(){
//             console.log(this)
//             // Object [global] {
//             //     global: [Circular],
//             //     clearInterval: [Function: clearInterval],
//             //     clearTimeout: [Function: clearTimeout],
//             //     setInterval: [Function: setInterval],
//             //     setImmediate: [Function: setImmediate] {
//             //       [Symbol(util.promisify.custom)]: [Function]
//             //     }
//             //   }
//             return ()=>{
//                 console.log(this)
//             // Object [global] {
//             //     global: [Circular],
//             //     clearInterval: [Function: clearInterval],
//             //     clearTimeout: [Function: clearTimeout],
//             //     setInterval: [Function: setInterval],
//             //     setImmediate: [Function: setImmediate] {
//             //       [Symbol(util.promisify.custom)]: [Function]
//             //     }
//             //   }
//             }
//         }
//     },
//     say:()=>{
//         console.log(this)
//         // this指向{}
//     }
// }

// let hi=obj.hi();
// hi();
// let sayHi=obj.sayHi();
// let fun1=sayHi();
// fun1();
// obj.say();


// //第七题
var obj={
    hi:function(){
        console.log(this);
        return ()=>{
            console.log(this);
        }
    },
    sayHi:function(){
        return function(){
            console.log(this,111);
             // Object [global] {
                //     global: [Circular],
                //     clearInterval: [Function: clearInterval],
                //     clearTimeout: [Function: clearTimeout],
                //     setInterval: [Function: setInterval],
                //     setTimeout: [Function: setTimeout] { [Symbol(util.promisify.custom)]: [Function] },
                //     queueMicrotask: [Function: queueMicrotask],
                //     clearImmediate: [Function: clearImmediate],
                //     setImmediate: [Function: setImmediate] {
                //       [Symbol(util.promisify.custom)]: [Function]
                //     }
                //       [Symbol(util.promisify.custom)]: [Function]
                //     }
                //   }
            return ()=>{
                console.log(this,222)
                // Object [global] {
                //     global: [Circular],
                //     clearInterval: [Function: clearInterval],
                //     clearTimeout: [Function: clearTimeout],
                //     setInterval: [Function: setInterval],
                //     setTimeout: [Function: setTimeout] { [Symbol(util.promisify.custom)]: [Function] },
                //     queueMicrotask: [Function: queueMicrotask],
                //     clearImmediate: [Function: clearImmediate],
                //     setImmediate: [Function: setImmediate] {
                //       [Symbol(util.promisify.custom)]: [Function]
                //     }
                //       [Symbol(util.promisify.custom)]: [Function]
                //     }
                //   }
            }
        }
    },
    say:()=>{
        console.log(this)
    }
}

let sayHi=obj.sayHi();
let fun1=sayHi();
fun1();
// let fun2=sayHi.bind(obj)()
// fun2();
// { hi: [Function: hi], sayHi: [Function: sayHi], say: [Function: say] } 111
// { hi: [Function: hi], sayHi: [Function: sayHi], say: [Function: say] } 222

 

