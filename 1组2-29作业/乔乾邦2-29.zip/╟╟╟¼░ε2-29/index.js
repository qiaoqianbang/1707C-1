//第一题
// function sayHi(){
//     console.log('Hello',this.name);
//     }
// var person = {
//     name: 'Person姓名',
//     sayHi: sayHi
//     }
// var name ='全局变量';

//this默认绑定
// // node 结果为Hello undefined  浏览器 结果为Hello Person姓名

// var Hi = person.sayHi;
// Hi();

// //第二题
// function sayHi(){
//     console.log('He11o,', this.name);
//    }
// var person1 = {
//     name: 'Person1的值',
//     sayHi: function(){
//         console.log(1111)
//     setTimeout(function(){
//         console.log(this)
//         console.log("Hello" ,this.name,9999)
//     })
//     }
// }
// var person2 = {
//     name: " Person2的值" ,
//     sayHi: sayHi
// }
// var name='全局变量name'
// person1.sayHi();
// setTimeout的this指向为Timeout，结果为 Hello undefined
// setTimeout(person2.sayHi,100);
//this默认绑定，指向setTimeout
// setTimeout(function(){
//     person2.sayHi();
// },200)
// this 隐式绑定 指向Person2 He11o,  Person2的值

// //第三题
// function sayHi(){
//     console.log('Hello',this.name);
// }
// var person={
//     name:'person名字',
//     sayHi:sayHi
// }
// var name='全局名字';
// var Hi=person.sayHi;
// Hi.call(person);
// 结果为 Hello person名字 call的this指向为person

// //第四题
// function sayHi() {
//     console.log('Hello', this.name);
// }
// var person = {
//     name: 'Person的值',
//     sayHi: sayHi,
// };
// var name = '全局的名字';
// var Hi = function(fn) {
//     fn();
// };
// Hi.call(person, person.sayHi);
//结果为Hello undefined  this默认绑定

// //第五题
// function sayHi(){
//     console.log('Hello',this.name)
// }
// var person={
//     name:'person的题',
//     sayHi:sayHi
// }
// var name='全局变量的值'
// var Hi=function(fn){
//     // console.log(fn,999)sayHi
//     fn.call(this)this绑定fn
// }
// Hi.call(person,person.sayHi);
//this绑定到person上
// 结果 Hello person的题

// 第六题
var obj = {
    hi: function() {
        console.log(this);
        return () => {
            console.log(this);
        };
    },
    sayHi: function() {
        return function() {
            console.log(this);
            return () => {
                console.log(this);
            };
        };
    },
    say: () => {
        console.log(this);
    },
};
let hi = obj.hi(); //this指向obj
hi();
let sayHi = obj.sayHi(); //this默认绑定 箭头函数中this绑定obj
let fun1 = sayHi();
fun1();
obj.say(); //obj
//第七题
// var obj = {
//     hi: function() {
//         console.log(this);
//         return () => {
//             console.log(this);
//         };
//     },
//     sayHi: function() {
//         return function() {
//             console.log(this);
//             return () => {
//                 console.log(this);
//             };
//         };
//     },
//     say: () => {
//         console.log(this);
//     },
// };
// let sayHi = obj.sayHi();//undefined obj
// let fun1 = sayHi();
// fun1();
// let fun2 = sayHi.bind(obj)();
// fun2();