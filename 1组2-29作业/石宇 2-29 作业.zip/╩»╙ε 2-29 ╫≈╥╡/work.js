// //第⼀题
// // function sayHi() {
// // 	console.log("Hello,", this.name);
// // }
// // var person = {
// // 	name: "Person姓名",
// // 	sayHi: sayHi
// // };
// // var name = "全局变量";
// // var Hi = person.sayHi;
// // Hi();

// //默认绑定
// //Hello, undefined

// //第⼆题
// function sayHi() {
// 	console.log("Hello,", this.name);
// }
// var person1 = {
// 	name: "Person1的值",
// 	sayHi: function() {
// 		setTimeout(function() {
// 			console.log("Hello,", this.name);
// 		});
// 	}
// };
// var person2 = {
// 	name: "Person2的值",
// 	sayHi: sayHi
// };
// var name = "全局变量name";
// person1.sayHi();
// //默认绑定
// //Hello, undefined
// setTimeout(person2.sayHi, 100);
// //默认绑定
// //Hello, undefined
// setTimeout(function() {
// 	person2.sayHi();
// }, 200);
// //隐式绑定
// //Hello, Person2的值

// function sayHi() {
// 	console.log("Hello,", this.name);
// }
// var person = {
// 	name: "Person名字",
// 	sayHi: sayHi
// };
// var name = "全局名字";
// var Hi = person.sayHi;
// Hi.call(person);

// //硬（显示）绑定
// //Hello, Person名字

// //第四题
// function sayHi(){
//     console.log('Hello,', this.name);//打印结果 :  Hello, undefined
// }
// var person = {
//     name: 'Person的值',
//     sayHi: sayHi
// }
// var name = '全局的名字';
// var Hi = function(fn) {
//     fn();
// }

// Hi.call(person, person.sayHi);

//  //第五题
// function sayHi(){
//     console.log('Hello,', this.name);//  打印结果 :   Hello, Person 
// }
// var person = {
//     name: 'Person的题',
//     sayHi: sayHi
// }
// var name = '全局变量的值';
// var Hi = function(fn) {
//     fn.call(this);
// }
// //this为默认绑定
// Hi.call(person, person.sayHi);

//第六题
// var obj = {
//     hi: function () {
//         console.log(1,this);
//         return () => { 
//             console.log(2,this);
//         }
//     },
//     sayHi: function () {
//         return function () {
//             console.log(3,this);
//             return () => {
//                 console.log(4,this);
//             }
//         }
//     },
//     say: () => {
//         console.log(5,this); 
//     }
// }
// let hi = obj.hi();
// hi();
// let sayHi = obj.sayHi();
// let fun1 = sayHi();
// fun1();
// obj.say();
/**
 *打印结果：
1 { hi: [Function: hi],sayHi: [Function: sayHi],say: [Function: say] }
2 { hi: [Function: hi],sayHi: [Function: sayHi], say: [Function: say] }
3 global
4 global
5 {}
 */
   
//第七题
// var obj = {
// hi: function(){
//     console.log(0,this);
//     return ()=>{
//         console.log(1,this);
//     }
// },
// sayHi: function(){
//     return function() {
//         console.log(2,this);
//         return ()=>{
//             console.log(3,this);
//         }
//     }
// },
// say: ()=>{
//     console.log(4,this);
// }
// }
// let sayHi = obj.sayHi();
// let fun1 = sayHi();
// fun1();
// let fun2 = sayHi.bind(obj)();
// fun2()

/**
* 0 未打印
* 1 未打印 
* 2 global { hi: [Function: hi],sayHi: [Function: sayHi], say: [Function: say] }
* 3 { hi: [Function: hi],sayHi: [Function: sayHi], say: [Function: say] }


*/