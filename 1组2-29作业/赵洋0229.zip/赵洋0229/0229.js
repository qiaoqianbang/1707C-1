//第⼀题
function sayHi(){
    console.log('Hello,', this.name);
}
var person = {
    name: 'Person姓名',
    sayHi: sayHi
}
var name = '全局变量';
var Hi = person.sayHi; //sayHi没有调用 默认绑定 this
Hi();   //   Hello,undefind

// 第⼆题

function sayHi(){
    console.log('Hello,', this.name);
}
var person1 = {
    name: 'Person1的值',
    sayHi: function(){
        setTimeout(function(){
        console.log('Hello,',this.name);
        })
    }
}
var person2 = {
    name: 'Person2的值',
    sayHi: sayHi
}
var name='全局变量name';
   person1.sayHi();
    setTimeout(person2.sayHi,100); //sayHi没有直接调用   默认绑定
    setTimeout(function(){  //setTimeout改变this指向
        person2.sayHi(); //sayHi直接调用   隐式绑定
   },200);
//    1.Hello, undefined
//    2.Hello, undefined
//    3.Hello, Person2的值

//第三题

function sayHi(){
    console.log('Hello,', this.name);
}
var person = {
    name: 'Person名字',
    sayHi: sayHi
}
var name = '全局名字';
var Hi = person.sayHi;
    Hi.call(person);  //call改变了this为person
// Hello, Person名字

//第四题
function sayHi(){
    console.log('Hello,', this.name);
}
var person = {
    name: 'Person的值',
    sayHi: sayHi
}
var name = '全局的名字';
var Hi = function(fn) {
    fn();
}
Hi.call(person, person.sayHi); //call改变了this指向
// Hello, undefined

 //第五题

function sayHi(){
    console.log('Hello,', this.name);
}
var person = {
    name: 'Person的题',
    sayHi: sayHi
}
var name = '全局变量的值';
var Hi = function(fn) {
    fn.call(this);//call让person.sayHi继承了person
}
Hi.call(person, person.sayHi); //call转变了Hi的this为person
// Hello, Person的题

//第六题

var obj = {
    hi: function(){
        console.log(this);
        return ()=>{
        console.log(this);
        }
    },
    sayHi: function(){
        return function() {
        console.log(this);
        return ()=>{
        console.log(this);
        }
        }
    },
    say: ()=>{
        console.log(this);
    }
}
let hi = obj.hi();
    hi();
let sayHi = obj.sayHi();
let fun1 = sayHi();
fun1();
obj.say();

//第七题

var obj = {
    hi: function(){
        console.log(this);
        return ()=>{
        console.log(this);
        }
    },
    sayHi: function(){
        return function() {
        console.log(this);
        return ()=>{
        console.log(this);
        }
        }
    },
    say: ()=>{
    console.log(this);
    }
}
let sayHi = obj.sayHi();
let fun1 = sayHi();
fun1();
let fun2 = sayHi.bind(obj)();
fun2();