import React, { Component } from 'react';
import Watcher from '../utils/watcher';
let watcher = new Watcher();
export default class Home extends Component {
    constructor(props) {
        super(props);
        watcher.on('list', List => {
            this.setState({
                List,
            });
        });
        watcher.on('value', value => {
            this.setState({
                InputVale: value,
            });
        });
        this.state = {
            InputVale: '',
            List: [],
        };
    }
    componentDidMount() {
        this.refs.input.focus();
    }
    //输入框事件
    change(e) {
        watcher.emit('value', e.target.value);
    }
    //复选框事件
    checked(e) {
        const { List } = this.state;
        let index = List.findIndex(i => i.content === e.target.name);
        List[index].flag = !List[index].flag;
        watcher.emit('list', List);
    }
    keypress(e) {
        const { InputVale, List } = this.state;
        if (e.which === 13 && InputVale !== '') {
            List.push({ content: InputVale, flag: false });
            this.setState({ InputVale: '' });
        }
    }
    remove(content) {
        const { List } = this.state;
        let index = List.findIndex(i => i.content === content);
        List.splice(index, 1);
        watcher.emit('list', List);
    }
    render() {
        const { InputVale, List } = this.state;
        return (
            <div>
                <label>
                    Tolist
                    <input
                        ref="input"
                        type="text"
                        value={InputVale}
                        onChange={e => this.change(e)}
                        onKeyPress={e => this.keypress(e)}
                    />
                </label>
                <div>
                    <h3>正在进行时{List.filter(i => !i.flag).length}</h3>
                    {List.filter(i => !i.flag).map((i, k) => {
                        return (
                            <div key={k}>
                                <p>
                                    <input
                                        type="checkbox"
                                        name={i.content}
                                        checked={i.flag}
                                        onChange={e => {
                                            this.checked(e);
                                        }}
                                    />
                                    {i.content}{' '}
                                    <span
                                        onClick={() => {
                                            this.remove(i.content);
                                        }}
                                    >
                                        删除
                                    </span>
                                </p>
                            </div>
                        );
                    })}
                </div>
                <div>
                    <h3>已经完成{List.filter(i => i.flag).length}</h3>
                    {List.filter(i => i.flag).map((i, k) => {
                        return (
                            <div key={k}>
                                <p>
                                    <input
                                        type="checkbox"
                                        name={i.content}
                                        checked={i.flag}
                                        onChange={e => {
                                            this.checked(e);
                                        }}
                                    />
                                    {i.content}{' '}
                                    <span
                                        onClick={() => {
                                            this.remove(i.content);
                                        }}
                                    >
                                        删除
                                    </span>
                                </p>
                            </div>
                        );
                    })}
                </div>
            </div>
        );
    }
}
