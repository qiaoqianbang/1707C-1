class Watcher {
    constructor() {
            this.events = [];
        }
        //订阅
    on(type, watcher) {
            if (this.events[type] instanceof Array) {
                this.events[type].push(watcher);
            } else {
                this.events[type] = [watcher];
            }
        }
        //发布
    emit(type, reset) {
        this.events[type].forEach(i => {
            i(reset);
        });
    }
}
export default Watcher;