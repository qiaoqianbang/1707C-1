import React, { Component } from 'react'
import Watcher from './Watcher'
let watcher=new Watcher()

class List extends Component{
    constructor(props){
        super(props)
        
        watcher.on('Title',(arr)=>{
            console.log(arr)
            this.setState({listData:arr})
            
        })
        watcher.on('Delete',(arr)=>{
            console.log(arr)
            this.setState({listData:arr})
            
        })
        watcher.on('Change',(arr,alarr)=>{
            this.setState({listData:arr,alList:alarr})
            
        })
        watcher.on('DeleteAly',(alarr)=>{
            this.setState({alList:alarr})
            
        })
        this.state={
            listData:[],
            alList:[],
            isVal:true,
        }
        
    }
    render(){
        const {listData,alList,isVal}=this.state
        return (
            <ul>
                <h1>正在进行 {listData.length}</h1> 
                {
                    listData.map((item,index)=>{
                        return <li key={index}> <input checked={!isVal} onChange={()=>{}} type="checkbox" onClick={()=>{
                            watcher.emit('Change',{id:item.id,checkVal:true,val:item.val})
                        }}/> {item.val} <button onClick={()=>{
                            watcher.emit('Delete',item.id)
                        }}>删除</button></li>
                    })
                }
                <h1>已完成 {alList.length}</h1>
                {
                    alList.map((item,index)=>{
                        return <li key={index}> <input  checked={isVal} onChange={()=>{}} type="checkbox" onClick={()=>{
                            watcher.emit('Change',{id:item.id,checkVal:false,val:item.val})
                        }}/> {item.val} <button onClick={()=>{
                            watcher.emit('DeleteAly',item.id)
                        }}>删除</button></li>
                    })
                }
            </ul>
        )
    }
}

class Header extends Component{
    render(){
        
        return (
            <ul>
                <input ref="val" type="text" placeholder="请输入"/>
                <button onClick={()=>{
                    watcher.emit('Title',{val:this.refs.val.value,id:new Date()*1})
                }}>添加</button>
            </ul>
        )
    }
}


class Content extends Component {
    render() {
        return (
            <div>
                <Header />
                <List />
            </div>
        )
    }
}
export default Content
