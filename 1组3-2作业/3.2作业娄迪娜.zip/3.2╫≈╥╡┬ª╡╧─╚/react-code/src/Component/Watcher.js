class Watcher{
    constructor(){
        this.events=[];
        this.arr=[];
        this.alList=[]
    }
    on(type,watcher){
        if(this.events[type] instanceof Array){
            this.events[type].push(watcher)
        }else{
            this.events[type]=[watcher]
        }
    }
    emit(type,reset){
        this.events[type].forEach(item=>{
            if(type==="Title"){
                 this.arr.push(reset)
                 item(this.arr)
            }
            if(type==="Delete"){
                let index=this.arr.findIndex(item=>item.id===reset)
                this.arr.splice(index,1)
                item(this.arr)
            }
            if(type==="Change"){
               
                const {id,checkVal,val}=reset
                console.log(checkVal)
                if(checkVal){
                    let index=this.arr.findIndex(item=>item.id===id)
                    this.arr.splice(index,1)
                    this.alList.push({val,id})
                    item(this.arr,this.alList)
                }else{
                    let index=this.alList.findIndex(item=>item.id===id)
                    this.alList.splice(index,1)
                    this.arr.push({val,id})
                    item(this.arr,this.alList)
                }
            }
            if(type==="DeleteAly"){
                let index=this.alList.findIndex(item=>item.id===reset)
                this.alList.splice(index,1)
                item(this.alList)
            }
           
        })
    }
}
export default Watcher
