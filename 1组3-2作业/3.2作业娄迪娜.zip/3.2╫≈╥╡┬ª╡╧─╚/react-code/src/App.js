import React from 'react';
import Content from './Component/Content'

function App() {
  return (
    <div className="App">
        <Content />
    </div>
  );
}

export default App;
