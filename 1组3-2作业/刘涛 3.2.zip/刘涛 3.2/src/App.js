import React, { Component } from 'react'
import A from './components/a/a'
class App extends Component {
  render() {
    return (
      <div>
        高阶组件
      </div>
    )
  }
}




export default A(App)
