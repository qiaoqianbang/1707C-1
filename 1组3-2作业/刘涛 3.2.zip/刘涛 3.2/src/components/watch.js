class Watch {
  constructor() {
    // 存储被观察者
    this.list = [];
    this.arr = []
    this.count = 1
  }
  // 发布
  on(type, name) {
    if (this.list[type] instanceof Array) {
      this.list[type].push(name)

    } else {
      this.list[type] = [name]
    }
    return "在哪里"

  }
  // 订阅
  emit(type, res) {

    this.list[type].forEach(() => {
      this.arr.push(res)
    })
    let newArr = Array.from(new Set(this.arr))
    this.list[type][this.list[type].length - this.count](newArr)
  }
}

export default Watch