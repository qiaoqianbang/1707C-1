import React, { Component } from 'react'
import Watchs from '../watch'
let watchs = new Watchs()
function A(Com) {
  return class a extends Component {
    constructor(props) {
      super(props)
      watchs.on('delete', () => {
        this.setState({
          list: []
        })
      })
      this.state = {
        title: "头部",
        setValue: "",
        list: [],
        cc: false,
        flag: true,
        count: 0

      }
    }
    renderFYNC() {
      let { list, count } = this.state;
      return list.map((item, index) => {
        return (
          <div key={index}>
            <input type="checkbox" checked={this.state.cc} onChange={(e) => {
              watchs.on("check", (v) => {
                if (v.slice(v.length - 1)[0]) {
                  this.setState({
                    cc: !this.state.cc,
                    flag: false
                  })
                } else {
                  this.setState({
                    cc: !this.state.cc,
                    flag: true
                  })
                }

              })
              watchs.emit("check", !this.state.cc)
            }}></input>
            <div>{item}</div>
            <button onClick={() => {
              watchs.emit("delete", [])
            }}>删除</button>
          </div>
        )
      })
    }
    render() {
      return (
        <div>
          <p>TodoList<input onInput={(e) => {
            this.setState({
              value: e.target.value
            })
          }} onKeyUp={(e) => {
            if (e.keyCode === 13) {
              watchs.on("setValue", (list) => {
                this.setState({
                  list,
                  count: list.length
                })

              })
              watchs.emit("setValue", this.state.value)


            }
          }
          }></input></p>
          <div>
            <h4>正在进行{!this.state.falg ? this.state.count : 0}</h4>
            <div>
              {
                this.state.flag ? this.renderFYNC() : []
              }
            </div>
          </div>
          <div>
            <h4>已经完成{this.state.falg ? this.state.count : 0}</h4>
            <div>
              {
                this.state.flag ? [] : this.renderFYNC()
              }
            </div>
          </div>
          <div>
            <div><Com /></div>
          </div>
        </div >
      )
    }
  }
}


export default A
