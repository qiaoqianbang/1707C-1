


// 观察者模式

// 被观察者
class B {
  constructor() {
    // 存储观察者
    this.list = []
    this.state = "被观察者我很被动"
  }
  // 添加观察者方法
  add(element) {
    this.list.push(element)
  }
  // 监听被观察者状态
  setState(element) {
    this.state = element
    this.list.forEach(item => {
      item.d(element)
    })
  }
}
// 观察者
class G {
  constructor(name) {
    this.name = name;
  }
  d(a) {
    console.log("我是" + this.name + a)
  }
}


let b = new B()
// 观察者1
let g1 = new G("g1")
// 观察者1
let g2 = new G("g2")
// 观察者1
let g3 = new G("g3")
b.add(g1)
b.add(g2)
b.setState("被观察者你很帅")
