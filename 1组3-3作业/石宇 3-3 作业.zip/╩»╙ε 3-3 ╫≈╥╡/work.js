Function.prototype.call = function(context){
    if(!context){
        // null undefined
        context = typeof window === 'undefined' ? global : window
    }
    context.fn = this;//改变this指向
    let rest = [...arguments].slice(1);
    let result = context.fn(...rest);//隐式绑定
    delete context.fn
    return result
}

Function.prototype.apply = function(context){
    if(!context){
        // null undefined
        context = typeof window === 'undefined' ? global : window
    }
    context.fn = this;//改变this指向
    let result;
    if(arguments[1]){
        // 如果第二个数是数组，传递给fn
        result=context.fn(...arguments[1])
    }else{
        result=context.fn();
    }
    delete context.fn
    return result
}

var foo = {
    name:'12'
}
var name = 'global'
function bar(job,age){
    console.log(this.name);
    console.log(job,age)
}
bar.call(foo,'p',2)
bar.apply(foo,['p',2])