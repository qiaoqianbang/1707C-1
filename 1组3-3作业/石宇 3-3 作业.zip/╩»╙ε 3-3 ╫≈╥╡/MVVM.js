// Observer类
class Observer{
    constructor(data){
        this.observer(data)
    }
    observer(data){
        if(data&&typeof data==="object"){
            for(let key in data){
                this.defineReactive(data,key,data[key])
            }
        }
    }
    defineReactive(obj,key,value){
        this.observer(value)
        Object.defineProperty(obj,key,{
            get(){
                console.log("get方法")
                return value
            },
            set(newValue){
                console.log("set方法")
                if(newValue!==value){
                    value = newValue
                }
            }
        })
    }
}

class Complie{
    constructor(el,vm){
        this.el=this.isElementNode(el)?el:document.querySelector(el)
        this.vm=vm;
        let fragment=this.node2fragment(this.el);
    }
    isElementNode(node){
        return node.nodeType===1
    }
    //将节点放到内存中
    node2fragment(node){
        let fragment=document.createDocumentFragment();
        let firstChild;
        while(firstChild=node.firstChild){
            fragment.appendChild(firstChild)
        }
        return fragment
    }
}


class Vue{
    constructor(options){
        this.el=options.el;
        this.data=options.data;
        if(this.el){
            //数据劫持
            new Observer(this.data)
            new Complie(this.el,this)
        }
    }
}
