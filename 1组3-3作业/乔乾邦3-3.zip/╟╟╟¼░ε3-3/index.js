Function.prototype.call = function(context) {
    if (!context) {
        // 判断传入的是null undefined
        context = typeof window === 'undefined' ? global : window;
    }
    context.fn = this; //改变this指向
    let rest = [...arguments].slice(1);
    let result = context.fn(...rest); //隐式绑定
    delete context.fn;
    return result;
};

Function.prototype.apply = function(context) {
    if (!context) {
        // 判断传入的是null undefined
        context = typeof window === 'undefined' ? global : window;
    }
    context.fn = this; //改变this指向
    let result;
    if (arguments[1]) {
        // 判断第二个参数是数组，传递给fn
        result = context.fn(...arguments[1]);
    } else {
        result = context.fn();
    }
    delete context.fn;
    return result;
};

var obj = {
    name: 'qq',
};
var name = 'global';

function bar(param, data) {
    console.log(this.name);
    console.log(param, data);
}
bar.call(obj, 'p', 2);
bar.apply(obj, ['p', 2]);

// class Observer {
//     constructor(data) {
//         this.observer(data);
//     }
//     observer(data) {
//         if (data && typeof data === 'object') {
//             for (let key in data) {
//                 this.define(data, key, data[key]);
//             }
//         }
//     }
//     define(obj, key, value) {
//         this.observer(value);
//         Object.defineProperty(obj, key, {
//             get() {
//                 console.log('get');
//                 return value;
//             },
//             set(param) {
//                 console.log('set');
//                 if (param !== value) {
//                     value = param;
//                 }
//             },
//         });
//     }
// }

// class Complie {
//     constructor(el, vm) {
//         this.el = this.isElementNode(el) ? el : document.querySelector(el);
//         this.vm = vm;
//         let fragment = this.node2fragment(this.el);
//     }
//     isElementNode(node) {
//         return node.nodeType === 1;
//     }
//     node2fragment(node) {
//         let fragment = document.createDocumentFragment();
//         let firstChild;
//         while ((firstChild = node.firstChild)) {
//             fragment.appendChild(firstChild);
//         }
//         return fragment;
//     }
// }