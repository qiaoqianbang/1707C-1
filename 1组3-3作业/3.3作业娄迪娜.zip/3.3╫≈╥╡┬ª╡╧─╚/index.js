// 1、编写call⽅法 apply⽅法需要写注释
Function.prototype.call=function(context){
    if(!context){//context传的值为null或undefined时
        context=typeof window === 'undefined' ? global : window
    }
    context.fn=this;
    let rest=[...arguments].slice(1)//除this之外的值
    let result=context.fn(...rest);//隐式绑定
    delete context.fn;//删除fn
    return result
}

Function.prototype.apply = function (context, arr) {
    var context = Object(context) || window;
    context.fn = this;

    var result;
    if (!arr) {//如果arr为空
        result = context.fn();
    }
    else {
        var args = [];
        for (var i = 0, len = arr.length; i < len; i++) {
            args.push('arr[' + i + ']'); //[ 'arr[0]', 'arr[1]' ]
        }
        console.log(context.fn(' + args + '),"222")
        result = eval('context.fn(' + args + ')')//将this指向赋值给result
    }

    delete context.fn
    return result;
}

var foo={
    name:'lala'
}
var name='haha'
function bar(job,age){
    console.log(this.name);
    console.log(job,age)
}
// bar.call(foo,['programmer',18])
// bar.apply(foo,['programmer',18])


// 2、画出MVVM的流程图


// new mvvm()=>Observer(数据劫持)(添加watcher)<=>(通知数据变化)Dep=>watcher
// new mvvm()=>compile(指令解析)=>(初始化视图)view Updater(订阅数据不变化，绑定更新函数)<=>(更新视图)watcher


// 3、编写Observer类 

let obj={
    name:'loudina',
    age:'20'
}
class Observer{
    constructor(data){
        this.observer(data)
    }
    observer(data){
        for(let key in data){
            let value=data[key]
            Object.defineProperty(data,key,{
                get(){
                    return value
                },
                set(){
                    if(newVal!==value){
                        value=newVal
                    }
                }
            })
        }
    }
}

// // 4、编写⼀个⽅法将节点放⼊内存中
function nodeFragment(node){//把节点加载到内存中防止页面多次刷新
    let fragment=document.createDocumentFragment();//创建文档碎片
    let firstChild;
    while(firstChild=node.firstChild){
        fragment.appendChild(firstChild)
    }
    return fragment

}
nodeFragment("节点")