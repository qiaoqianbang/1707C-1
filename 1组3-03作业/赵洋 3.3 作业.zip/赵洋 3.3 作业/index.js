
function add(a, b) {
    return a + b;
}

function sub(a, b) { 
    return a - b;
}

console.log(add.call(sub, 2, 1));

function People(name, age) {
    this.name = name;
    this.age = age;
}

function Student(name, age, grade) {
    People.apply(this, name, age);  
    this.grade = grade;
}

let student = new Student('赵洋', 21, '八维');
console.log(student.name + student.age + student.grade);




class Observer{
    constructor(data){
        this.observer(data)
    }
    observer(data){
        if(data && typeof data === "object"){
            for(let key in data){
                this.defineReactive(data,key,data[key])
            }
        }
    }
    defineReactive(obj,key,value){
        this.observer(value)
        Object.defineProperty(obj,key,{
            get(){
                console.log("get方法")
                return value
            },
            set(newValue){
                console.log("set方法")
                if(newValue!==value){
                    value = newValue
                }
            }
        })
    }
}

// 4

class Complie{
    constructor(el,vm){
        this.el = this.isElementNode(el)?el:document.querySelector(el)
        this.vm = vm;
        let fragment = this.node2fragment(this.el);
        this.complie(fragment)
        this.el.appendChild(fragment)
    }
    isElementNode(node){
        return node.nodeType === 1
    }
    node2fragment(node){
        let fragment = document.createDocumentFragment();
        let firstChild;
        while(firstChild = node.firstChild){
            fragment.appendChild(firstChild)
        }
        return fragment
    }
    complie(node){
        let childNodes = node.childNodes;
        [...childNodes].forEach(child => {
            if(this.isElementNode(child)){
                this.complieElement(child)
                this.complie(child)
            }else{
                this.complieText(child)
            }
        })
    }
    complieElement(node){

    }
    complieText(node){

    }
}
