class Vue {
  constructor(data) {
    this.el = data.el
    this.data = data.data
    if (this.el) {
      // 数据劫持
      new Observer()
      //指令解析 将节点归并到虚拟内存里统一化管理为了减少内存占用
      new Complie(this.el)
    }
  }
}
// 指令解析
class Complie {
  constructor(el) {
    // 根节点
    this.el = this.isElement(el) ? el : document.querySelector(el);
    // 将节点归并到虚拟内存里统一化管理为了减少内存占用
    let resdata = this.guibing(this.el);
    // 遍历节点 哪个节点变更新哪个 
    this.ForElement(resdata);
    // console.log(resdata, "deee");
    // window.f = resdata;
    // console.log(resdata)
    this.el.appendChild(resdata)

  }

  guibing(el) {
    // 归并的内存容器
    let res = document.createDocumentFragment()
    let ress;
    while (ress = el.firstChild) {
      res.appendChild(ress)
    }

    return res
  }
  // 遍历节点 哪个节点变更新哪个
  ForElement(el) {
    let node = el.childNodes;
    [...node].forEach(item => {
      // 递归遍历节点 最深处 判断是不是元素节点 
      if (this.isElement(item)) {
        // 元素节点
        // console.log(item)
        // 递归遍历节点
        this.ForElement(item)

      } else {
        // 文本节点
        // console.log(item)
      }


    })
  }
  // 判断是不是元素节点 
  isElement(element) {
    return element.nodeType === 1
  }
  //  递归遍历节点
  dgElement(node) {
    this.ForElement(node)
  }
}

// 数据劫持
class Observer {
  constructor(data) {
    // 第一步数据属性转换成服务器属性
    this.setState(data)
    this.count = 0
  }
  // 遍历数据
  setState(data) {
    if (data && data instanceof Object) {
      for (let key in data) {
        // 递归遍历
        console.log(data, "Data")
        this.dg(data, key, data[key])
      }

    }

  }
  // 递归遍历数据 并转换成服务器属性
  dg(data, key, value) {
    this.setState(value)
    Object.defineProperty(data, key, {
      get() {
        return value
      },
      set(newvalue) {
        if (newvalue !== value) {
          value = newvalue
        }
      }
    })
  }

}