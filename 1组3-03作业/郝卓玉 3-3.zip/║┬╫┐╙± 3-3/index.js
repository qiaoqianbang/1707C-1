// 1.编写call方法apply方法需要写注释
var fn=function(arg1,arg2){
    //do something
}
fn.call(this,arg1,arg2)//参数散列 
// call则可以传递多个参数，第一个参数和apply一样，是用来替换的对象，后边是参数列表
fn.apply(this,[arg1,arg2])//参数使用数组包裹
// apply最多只能有两个参数——新this对象和一个数组argArray，如果arg不是数组则会报错TypeError

//2.画出MVVM的流程图

// MVVM实现思路

new MVVM()
// 数据劫持----Observer ----Dep ----通知数据变化
                                                                 watcher
// 指令解析----Compile  ----初始化视图 ----view Updater

//3.编写Observer类
//数据劫持
class Observer{
    //数据属性变成访问器属性
    constructor(data){
        this.observer(data)
    }
    observer(data){
        if(data&&typeof data==='object'){
            for(let key in data){
                this.defineReactive(data,key,data[key])
            }
        }
    }
    defineReactive(obj,key,value){
        this.observer(value)
        Object.defineProperties(obj,key,{
            get(){
                console.log('get方法')
                return value
            },
            set(newValue){
                if(newValue!==value){
                    value=newValue
                }
            }
        })
    }
}

//数据劫持
new Observer(this.data)
//4.编写一个方法将节点放入内存中
class Complie{
    constructor(el,vm){
        //el是不是一个元素
        this.el=this.isElementNode(el)?el:document.querySelector(el)
        this.vm=vm
        //把节点加载到内存中
        let fragment=this.node2fragment(this.el);
        //window.f=fragment
        //编译末班数据
        this.compile(fragment)
        //把文档碎片中的内容独处
        this.el.appendChild(fragment)
    }
    //判断是不是元素节点
    isElementNode(node){
        return node.nodeType===1
    }
    //把节点储存到内存中 避免页面多次刷新
    node2fragment(node){
        let fragment=document.createDocumentFragment();
        let firstChild;
        while(firstChild = node.firstChild){
            fragment.appendChild(firstChild)
        }
        return fragment
    }
    //核心的编译方法
    compile(node){
        let childNodes=node.childNodes;
        //需要递归遍历节点
        [...childNodes].forEach(child=>{
            if(this.isElementNode(child)){
                //判断是否是元素节点
                this.complieElement(child)
                this.compile(child)
            }else{
                //判断是否是文本节点
                this.complieText(child)
            }
        })
    }
    complieElement(node){
        //操作元素节点
    }
    complieText(node){
        //操作文本节点
    }
}

new Complie(this.el,this)