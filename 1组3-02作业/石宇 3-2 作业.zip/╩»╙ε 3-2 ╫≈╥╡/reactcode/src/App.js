import React,{Component} from 'react';
import Home from './components/home'

export default class App extends Component {
	constructor(props) {
		super(props);
	}
	render() {
		return (
			<div className="App">
				<Home></Home>
			</div>
		);
	}
}
