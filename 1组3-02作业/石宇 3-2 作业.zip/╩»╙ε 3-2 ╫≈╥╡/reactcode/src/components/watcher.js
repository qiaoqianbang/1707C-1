export default class Watcher{
    constructor(){
        this.events=[];
    }
    on(type,watcher){
        if(this.events[type] instanceof Array){
            this.events[type].push(watcher);
        }else{
            this.events[type]=[watcher];
        }
    }
    emit(type,reset){
        this.events[type].forEach(item=>item(reset));
        console.log(this.events[type])
    }
}