import React, { Component } from 'react'
import Watcher from './watcher';
const watcher=new Watcher();

export default class Home extends Component {
    constructor(props){
        super(props);
        this.state={
            text:''
        };
    }
    publish=()=>{
        watcher.emit("pending",this.state.text);
        this.setState({text:''})
    }
    render() {
        return (
            <div className="home">
                ToDoList
                <input 
                type="text" 
                value={this.state.text} 
                onChange={e=>this.setState({text:e.target.value})}
                onKeyDown={e=>{if(e.keyCode===13){this.publish()}}}
                />
                <Pending></Pending>
                <Resolve></Resolve>
            </div>
        )
    }
}

class Pending extends Component{
    constructor(props){
        super(props);
        this.state={
            list:[],
            count:0
        };
        watcher.on("pending",name=>{
            let arr=this.state.list;
            arr.push(name);
            this.setState({
                list:arr,
                count:this.state.count+1
            })
        })
    }
    move=name=>{
        watcher.emit("resolve",name);
        let arr=this.state.list;
        let index=arr.findIndex(i=>i===name);
        arr.splice(arr.indexOf(index));
        this.setState({
            list:arr,
            count:this.state.count-1
        })
    }
    del=name=>{
        let arr=this.state.list;
        let index=arr.findIndex(i=>i===name);
        arr.splice(arr.indexOf(index));
        this.setState({
            list:arr,
            count:this.state.count-1
        })
    }
    render() {
		return (
			<div>
				<h3>正在进行{this.state.count}</h3>
				<ol>
					{this.state.list.map((item, index) => {
						return (
							<li key={index}>
								<input
									type="checkbox"
									onChange={() => {
										this.move(item);
									}}
								/>
								<span>{item}</span>
								<button
									onClick={() => {
										this.del(item);
									}}
								>
									删除
								</button>
							</li>
						);
					})}
				</ol>
			</div>
		);
	}
}

class Resolve extends Component {
	constructor(props) {
		super(props);
		this.state = {
			list: [],
			count: 0
		};
		watcher.on("resolve", name => {
			let arr = this.state.list;
			arr.push(name);
			this.setState({
				list: arr,
				count: this.state.count + 1
			});
		});
	}
	del = name => {
		let arr = this.state.list;
		let index = arr.findIndex(i => {
			return i === name;
		});
		arr.splice(index);
		this.setState({
			list: arr,
			count: this.state.count - 1
		});
	};
	render() {
		return (
			<div>
				<h3>已经完成{this.state.count}</h3>
				<ol>
					{this.state.list.map((item, index) => {
						return (
							<li key={index}>
								<input type="checkbox" defaultChecked={true} />
								<span>{item}</span>
								<button
									onClick={() => {
										this.del(item);
									}}
								>
									删除
								</button>
							</li>
						);
					})}
				</ol>
			</div>
		);
	}
}
