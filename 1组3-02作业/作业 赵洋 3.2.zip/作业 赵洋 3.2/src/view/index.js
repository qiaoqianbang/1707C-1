import React, { Component } from 'react';
import Wacther from "./wacther"
let wacther = new Wacther(); 
class Search extends Component {

  render() {
    return (
      <div>
     todolist
        <input type="text" ref={"k"} />
        <button onClick={() => this.onChangeFn()} >添加</button>
      </div>
    )
  }
  onChangeFn() {
    wacther.emit('title', this.refs.k.value);
  }
}
class Stocks extends Component {
  constructor(props) {
    super(props);
    wacther.on('title', (title) => {
      let arr = this.state.title;
      arr.push(title);
      this.setState({
        title: arr
      })
    })
    wacther.on('stocks', (title) => {
      let arr = this.state.title;
      arr.push(title);
      this.setState({
        title: arr
      })
    })
    this.state = {
      title: []
    }
  }
  getone(v) {
    let arr = []
    this.state.title.map(item => {
      if (item === v) {
        return
      }
      arr.push(item)
    })
    this.setState({
      title: arr
    })
    wacther.emit('undone', v)
  }
  render() {
    return (
      <div>
        <h3>任务成功</h3>
        {this.state.title.map((v, i) => {
          return (
            <div key={i}>
              <span>{i + 1}</span>
              <input type="checkbox" name="" id="" onChange={() => this.getone(v)} />
              <p key={i}>{v}</p>
              <p>删除</p>
            </div>
          )
        })}
      </div>
    )
  }
}
class Undone extends Component {
  constructor(props) {
    super(props);
    wacther.on('undone', (v) => {
      let arr = this.state.obj;
      arr.push(v);
      this.setState({
        obj: arr
      })
    })
    this.state = {
      obj: []
    }
  }
  getanyone(v) {
    let arr = []
    this.state.obj.map(item => {
      if (item === v) {
        return
      }
      arr.push(item)
    })
    this.setState({
      obj: arr
    })
    wacther.emit('stocks', v)
  }
  render() {
    return (
      <div>
        <h3>任务失败</h3>
        {this.state.obj.map((v, i) => {
          return (
            <div key={i}>
              <span>{i + 1}</span>
              <input type="checkbox" name="" id="" onChange={() => this.getanyone(v)} />
              <p key={i}>{v}</p>
              <p>删除</p>
            </div>
          )
        })}
      </div>
    )
  }
}
class Index extends Component {
  render() {
    return (
      <div>
        <Search />
        <Stocks />
        <Undone />
      </div>
    )
  }
}
export default Index