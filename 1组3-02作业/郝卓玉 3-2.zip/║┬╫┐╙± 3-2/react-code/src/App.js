import React, { Component } from 'react'
import './App.css';
import Home from'./component/home'

export default class App extends Component {
  // constructor(props){
  //   super(props);
  //   this.state={};
  // }
  render() {
    return (
      <div>
        <div className='app'>
          <Home />
        </div>
      </div>
    )
  }
}
