import React, { Component } from 'react'
import Watcher from './Watch'
const watcher=new Watcher();

export default class home extends Component {
    constructor(props){
        super(props);
        this.state={
            text:''
        }
    }
    int=(key,e)=>{
        
        this.setState({
           [key]:e.target.value
        })
    }
    publish=()=>{
        watcher.emit('pending',this.state.text)
        this.setState({
            text:''
        })
    }
    render() {
        return (
            <div>
                TodoList:
                <input type="text" value={this.state.text} onChange={(e)=>{this.int("text",e)}} onKeyDown={e=>{
                    if(e.keyCode===13){
                        this.publish()
                    }
                }}/>
                <Pending />
                <Complete />
            </div>
        )
    }
}
class Pending extends Component {
    constructor(props){
        super(props)
        this.state={
            list:[],
            count:0
        }
        watcher.on('pending',name=>{
            let arr=this.state.list;
            arr.push(name)
            this.setState({
                list:arr,
                count:this.state.count+1
            })
        })
    }

    move=name=>{
        watcher.emit('resolve',name)
        let arr=this.state.list;
        let index=arr.findIndex(item=>{
            return item===name
        })
        arr.splice(arr.indexOf(index))
        this.setState({
            list:arr,
            count:this.state.count-1
        })
    }

    del=name=>{
        let arr=this.state.list;
        let index=arr.findIndex(item=>{
            return item===name
        })
        arr.splice(index)
        this.setState({
            list:arr,
            count:this.state.count-1
        })
    }
    render() {
        return (
            <div>
                <h3>正在进行{this.state.count}</h3>
                <div>
                    {
                        this.state.list.map((item,index)=>{
                            return <div key={index}>
                                <input type="checkbox" onChange={()=>{this.move(item)}}/><span>{item}</span><button onClick={()=>{this.del(item)}}>删除</button>
                            </div>
                        })
                    }
                </div>
            </div>
        )
    }
}
class Complete extends Component {
    constructor(props){
        super(props)
        this.state={
            list:[],
            count:0
        }
        watcher.on('resolve',name=>{
            let arr=this.state.list;
            arr.push(name)
            this.setState({
                list:arr,
                count:this.state.count+1
            })
        })
    }
    del=name=>{
        let arr=this.state.list;
        let index=arr.findIndex(item=>{
            return item===name
        })
        arr.splice(index)
        this.setState({
            list:arr,
            count:this.state.count-1
        })
    }
    render() {
        return (
            <div>
                <h3>已完成{this.state.count}</h3>
                <div>
                    {
                        this.state.list.map((item,index)=>{
                            return <div key={index}>
                                <input type="checkbox" onChange={()=>{this.move(item)}}/><span>{item}</span><button onClick={()=>{this.del(item)}}>删除</button>
                            </div>
                        })
                    }
                </div>
            </div>
        )
    }
}

