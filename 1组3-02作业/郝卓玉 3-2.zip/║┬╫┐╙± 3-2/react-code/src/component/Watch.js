export default class Watch {
    constructor(){
        this.events=[];
    }
    on(type,watch){
        if(this.events[type] instanceof Array){
            this.events[type].push(watch)
        }else{
            this.events[type]=[watch];
        }
    }
    emit(type,rest){
        this.events[type].forEach(item=>item(rest))
    }
}
